# V1LE Farm - Project TODO

## Core Features
- [x] Telegram authentication and bot integration
- [x] Home page with security messaging and gradient cards
- [x] Category/Shop page with product catalog
- [x] Profile page with user bio and settings
- [x] Order History page with status tracking
- [x] Admin panel with order management

## Product & Ordering
- [x] God Complex product ($10/gram, min 2g)
- [x] Coming Soon product placeholder
- [x] Quantity selection (preset: 2g, 2.5g, 5g, 10g + custom)
- [x] Product stock management (in-stock/out-of-stock toggle)
- [x] Store open/close toggle with custom closure messages
- [x] Product category system (All, Flower)

## User Features
- [x] Mandatory username setup (min 3 chars, alphanumeric + underscores)
- [x] User profile pictures with S3 storage
- [x] Profile picture upload with drag-to-crop functionality
- [x] Profile picture display with red glow effect in header
- [x] Profile picture on all pages (Home, Category, OrderHistory, Profile, Admin)
- [x] Username initial with gradient background when no picture set
- [x] User bio and Telegram username management
- [x] Profile edit/view mode toggle

## Review System
- [x] One review per user per product
- [x] Review editing capability
- [x] Average rating display with star ratings
- [x] Review count display

## Order Management
- [x] Order creation with Telegram username validation
- [x] Order status tracking (pending, approved, rejected, cancelled)
- [x] Cancel pending orders functionality
- [x] Delete completed/rejected/cancelled orders
- [x] Automatic order cleanup (approved/rejected orders older than 5 days)
- [x] Persistent revenue tracking that survives cleanup
- [x] Revenue reset functionality in admin panel

## Telegram Integration
- [x] Telegram bot notifications to admin chat
- [x] Telegram group notifications
- [x] Interactive approve/reject buttons in Telegram
- [x] Message editing on button click (shows status + admin + timestamp)
- [x] Order cancellation notifications
- [x] Order deletion notifications
- [x] Telegram username requirement for orders

## Admin Features
- [x] Admin panel with order statistics
- [x] Order list with approve/reject/delete buttons
- [x] Individual order deletion
- [x] Bulk delete all orders
- [x] User management with role assignment
- [x] User search functionality
- [x] Product stock toggle
- [x] Store open/close management
- [x] Revenue tracking and reset

## UI/UX
- [x] Black and red theme with white text
- [x] Mobile-responsive design
- [x] Startup video splash screen (plays once per session)
- [x] Gradient cards and visual effects
- [x] Profile picture with red glow in navigation
- [x] Hover effects and transitions
- [x] Loading states and error handling
- [x] Empty state messaging

## Technical Implementation
- [x] Next.js + React + TypeScript
- [x] tRPC for API communication
- [x] Drizzle ORM for database
- [x] S3 storage for profile pictures
- [x] Telegram Bot API integration
- [x] Session-based authentication
- [x] Database schema with users, orders, reviews, revenue, store status
- [x] Automatic cleanup service (runs hourly)

## Design System
- [x] V1LE Farm branding and logo
- [x] Consistent color palette (black, red, white)
- [x] Typography and spacing system
- [x] Component library with shadcn/ui
- [x] Responsive breakpoints (mobile, tablet, desktop)

## Testing & Verification
- [x] Profile picture display consistency across all pages
- [x] Mobile responsiveness verification
- [x] Telegram bot integration testing
- [x] Order management flow testing
- [x] Admin panel functionality testing
- [x] User authentication flow testing


## Latest Enhancements (Current)
- [x] Out-of-stock indicator near product name when God Complex is unavailable
- [x] Profile picture spin animation on click (0.8s smooth rotation)
- [x] Animated grainy background effect on all pages
- [x] Email management in user profile (add/edit email address)
- [x] Falling cannabis flower animation on all pages (9 different flower images)
- [x] Cannabis flower images extracted and resized to 80x80px
- [x] Profile picture spin animation on Home, Category, OrderHistory, Admin, and Profile pages
- [x] All animations and effects verified working across all pages
- [x] Rolled back to stable checkpoint a6270876 with all features confirmed working



## Bug Fixes (Current)
- [x] Fix quantity calculation - 2.5g showing as 3g in order confirmation (changed quantity field to decimal type)
- [x] Verify all preset quantities (2g, 2.5g, 5g, 10g) display correctly
- [x] Make falling cannabis flowers more visible/brighter against black background (increased opacity to 0.85, added glow effects)
- [x] Increase opacity and add glow effect to cannabis flower images (added drop-shadow filters)
- [x] Add animations to OrderHistory page (grainy background, falling flowers, profile spin)
- [x] Add animations to Admin page (grainy background, falling flowers, profile spin)
- [x] Add animations to Profile page (grainy background, falling flowers, profile spin)
- [x] All pages now have consistent animated grainy background and falling cannabis flower effects
- [x] Profile picture spin animation working on all pages (Home, Category, OrderHistory, Admin, Profile)




## Major Refactoring - Independence from Manus (Current)
- [x] Update database schema with passwordHash, themeColor, sessions table
- [x] Create authentication utilities (password hashing, JWT tokens)
- [x] Implement custom OAuth/authentication system (replace Manus OAuth)
- [x] Create user registration page with email/password
- [x] Create custom login page (replace Manus login)
- [x] Implement JWT token management for sessions
- [x] Add password hashing and security (PBKDF2)
- [ ] Add authentication procedures to server routers (login, register, updateThemeColor)
- [ ] Add password/email/username update procedures to routers
- [ ] Remove all Manus OAuth dependencies from code
- [ ] Replace Manus user context with custom user context
- [ ] Implement logout functionality with session clearing
- [ ] Implement rainbow LED color system with HSL rotation
- [ ] Add color preference storage in user profile
- [ ] Create color picker in profile settings
- [ ] Update all red (#EF4444) elements to use dynamic color
- [ ] Build complete account management page with all editable fields
- [ ] Add password change functionality with validation
- [ ] Add username change with availability check
- [ ] Add email change with verification
- [ ] Add telegram username change
- [ ] Implement dynamic price calculation based on quantity
- [ ] Display price per gram in real-time as quantity changes
- [ ] Update order confirmation to show correct quantity and price
- [ ] Remove all Manus branding from UI
- [ ] Remove Manus notification system
- [ ] Remove Manus storage dependencies
- [ ] Test complete authentication flow
- [ ] Test all account management features
- [ ] Test rainbow color system across all pages
- [ ] Test dynamic pricing display

