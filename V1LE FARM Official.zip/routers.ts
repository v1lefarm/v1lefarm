    deleteAllOrders: protectedProcedure.mutation(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      const success = await deleteAllOrders();
      return { success };
    }),

    getAllUsers: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      return await getAllUsers();
    }),

    updateUserRole: protectedProcedure
      .input(
        z.object({
          userId: z.string(),
          role: z.enum(["admin", "user"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        const success = await updateUserRole(input.userId, input.role);
        return { success };
      }),

    getRevenue: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      return await getRevenue();
    }),

    resetRevenue: protectedProcedure.mutation(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new Error("Unauthorized: Admin access required");
      }
      await resetRevenue();
      return { success: true };
    }),

    getStoreStatus: publicProcedure.query(async () => {
      return await getStoreStatus();
    }),

    updateStoreStatus: protectedProcedure
      .input(
        z.object({
          isOpen: z.boolean().optional(),
          closedMessage: z.string().optional(),
          inStock: z.boolean().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new Error("Unauthorized: Admin access required");
        }
        await updateStoreStatus(input.isOpen, input.closedMessage, input.inStock);
        return { success: true };
      }),
  }),

  reviews: router({
    create: protectedProcedure
      .input(
        z.object({
          productName: z.string(),
          rating: z.number().min(1).max(5),
          comment: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createReview({
          userId: ctx.user.id,
          productName: input.productName,
          rating: input.rating,
          comment: input.comment,
        });
      }),

    getByProduct: publicProcedure
      .input(z.object({ productName: z.string() }))
      .query(async ({ input }) => {
        return await getProductReviews(input.productName);
      }),

    getUserReview: protectedProcedure
      .input(z.object({ productName: z.string() }))
      .query(async ({ ctx, input }) => {