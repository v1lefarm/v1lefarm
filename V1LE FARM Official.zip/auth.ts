import crypto from 'crypto';
import { ENV } from './env';

// Simple password hashing using crypto (in production, use bcrypt)
export function hashPassword(password: string): string {
  return crypto
    .pbkdf2Sync(password, ENV.cookieSecret, 1000, 64, 'sha512')
    .toString('hex');
}

export function verifyPassword(password: string, hash: string): boolean {
  const hashOfInput = hashPassword(password);
  return hashOfInput === hash;
}

// JWT Token generation
export function generateToken(userId: string): string {
  const payload = {
    userId,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + 7 * 24 * 60 * 60, // 7 days
  };

  // Simple JWT-like token (in production use jsonwebtoken library)
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64');
  const body = Buffer.from(JSON.stringify(payload)).toString('base64');
  
  const signature = crypto
    .createHmac('sha256', ENV.cookieSecret)
    .update(`${header}.${body}`)
    .digest('base64');

  return `${header}.${body}.${signature}`;
}

export function verifyToken(token: string): { userId: string; iat: number; exp: number } | null {
  try {
    const [header, body, signature] = token.split('.');
    
    const expectedSignature = crypto
      .createHmac('sha256', ENV.cookieSecret)
      .update(`${header}.${body}`)
      .digest('base64');

    if (signature !== expectedSignature) {
      return null;
    }

    const payload = JSON.parse(Buffer.from(body, 'base64').toString());
    
    if (payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }

    return payload;
  } catch {
    return null;
  }
}

export function generateSessionId(): string {
  return crypto.randomBytes(32).toString('hex');
}

