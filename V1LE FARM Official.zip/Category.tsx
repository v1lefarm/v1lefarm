import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { useState, useEffect } from "react";
import { Star, Lock, ShoppingBag, Package } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

const PRODUCTS = [
  {
    id: "god-complex",
    name: "God Complex",
    category: "Flower",
    description: "Premium cannabis strain with exceptional quality",
    price: 10,
    image: "/god-complex.png",
    available: true,
    rating: 4.5,
    reviews: 12,
  },
  {
    id: "coming-soon",
    name: "Coming Soon",
    category: "Flower",
    description: "Exciting new products launching soon",
    price: null,
    image: null,
    available: false,
    rating: 0,
    reviews: 0,
  },
];

const CATEGORIES = ["All", "Flower"];

export default function Category() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedProduct, setSelectedProduct] = useState(PRODUCTS[0]);
  const [quantity, setQuantity] = useState(2);
  const [customQuantity, setCustomQuantity] = useState("");
  const [useCustom, setUseCustom] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  
  const handleProfilePictureClick = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setTimeout(() => setIsSpinning(false), 800);
  };
  
  // Falling cannabis flowers effect
  useEffect(() => {
    const flowerImages = [
      '/cannabis/flower-1.png',
      '/cannabis/flower-2.png',
      '/cannabis/flower-3.png',
      '/cannabis/flower-4.png',
      '/cannabis/flower-5.png',
      '/cannabis/flower-6.png',
      '/cannabis/flower-7.png',
      '/cannabis/flower-8.png',
      '/cannabis/flower-9.png',
    ];
    
    const createFlower = () => {
      const flower = document.createElement('div');
      flower.className = 'falling-flower';
      const randomFlower = flowerImages[Math.floor(Math.random() * flowerImages.length)];
      const randomLeft = Math.random() * 100;
      const randomDuration = 8 + Math.random() * 4;
      const randomDelay = Math.random() * 2;
      
      flower.style.left = randomLeft + '%';
      flower.style.animationDuration = randomDuration + 's';
      flower.style.animationDelay = randomDelay + 's';
      flower.innerHTML = `<img src="${randomFlower}" alt="flower" />`;
      
      document.body.appendChild(flower);
      
      setTimeout(() => flower.remove(), (randomDuration + randomDelay) * 1000);
    };
    
    const interval = setInterval(createFlower, 1500);
    
    return () => clearInterval(interval);
  }, []);
  
  const presetQuantities = [2, 2.5, 5, 10];
  
  const [rating, setRating] = useState(0);
  const [reviewComment, setReviewComment] = useState("");
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  
  const { data: reviews, refetch: refetchReviews } = trpc.reviews.getByProduct.useQuery(
    { productName: selectedProduct.name },
    { enabled: isAuthenticated && selectedProduct.available }
  );
  
  const { data: storeStatus } = trpc.admin.getStoreStatus.useQuery();
  
  const { data: userReview, refetch: refetchUserReview } = trpc.reviews.getUserReview.useQuery(
    { productName: selectedProduct.name },
    { enabled: isAuthenticated && selectedProduct.available }
  );
  
  useEffect(() => {
    if (userReview) {
      setRating(userReview.rating);
      setReviewComment(userReview.comment || "");
      setIsEditing(true);
    } else {
      setRating(0);
      setReviewComment("");
      setIsEditing(false);
    }
  }, [userReview, selectedProduct]);
  
  const averageRating = reviews && reviews.length > 0
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : "0.0";
  
  const createReviewMutation = trpc.reviews.create.useMutation({
    onSuccess: () => {
      toast.success("Review posted successfully!");
      setShowReviewForm(false);
      refetchReviews();
      refetchUserReview();
    },
    onError: (error) => {
      toast.error(`Failed to post review: ${error.message}`);
    },
  });
  
  const updateReviewMutation = trpc.reviews.update.useMutation({
    onSuccess: () => {
      toast.success("Review updated successfully!");
      setShowReviewForm(false);
      refetchReviews();
      refetchUserReview();
    },
    onError: (error) => {
      toast.error(`Failed to update review: ${error.message}`);
    },
  });
  
  const handleSubmitReview = () => {
    if (rating === 0) {
      toast.error("Please select a rating");
      return;
    }

    if (isEditing) {
      updateReviewMutation.mutate({
        productName: selectedProduct.name,
        rating,
        comment: reviewComment,
      });
    } else {
      createReviewMutation.mutate({
        productName: selectedProduct.name,
        rating,
        comment: reviewComment,
      });
    }
  };

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      toast.success("Order placed successfully!");
      setQuantity(2);
      setCustomQuantity("");
      setUseCustom(false);
      setLocation("/orders");
    },
    onError: (error) => {
      toast.error(`Failed to place order: ${error.message}`);
    },
  });

  const handlePlaceOrder = () => {
    if (!isAuthenticated) {
      window.location.href = getLoginUrl();
      return;
    }

    if (!user?.telegramUsername) {
      toast.error("Please set your Telegram username in your profile first");
      setLocation("/profile");
      return;
    }

    const finalQuantity = useCustom ? parseFloat(customQuantity) : quantity;

    if (!finalQuantity || finalQuantity < 2) {
      toast.error("Minimum order is 2 grams");
      return;
    }

    if (finalQuantity > 0 && finalQuantity < 2.5 && finalQuantity !== 2) {
      toast.error("Quantity must be at least 2g or between 2.5g and higher");
      return;
    }

    createOrderMutation.mutate({
      productName: selectedProduct.name,
      quantity: finalQuantity,
      telegramUsername: user.telegramUsername,
      pricePerGram: selectedProduct.price || 0,
    });
  };

  const filteredProducts = selectedCategory === "All"
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen flex flex-col bg-background grainy-bg">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                <img src="/logo.v1le.png" alt="V1LE Farm" className="h-8 w-8 sm:h-10 sm:w-10 invert" />
                <span className="text-lg sm:text-xl font-bold text-primary">V1LE Farm</span>
              </div>
            </Link>
            <nav className="flex items-center gap-1 sm:gap-4">
              <Link href="/category">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Shop</Button>
              </Link>
              <Link href="/orders">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Orders</Button>
              </Link>
              {user?.role === "admin" && (
                <Link href="/admin">
                  <Button variant="ghost" size="sm" className="text-xs sm:text-sm hidden sm:inline-flex">Admin</Button>
                </Link>
              )}
              <Link href="/profile">
                <div 
                  onClick={handleProfilePictureClick}
                  className={`relative w-10 h-10 sm:w-12 sm:h-12 rounded-full overflow-hidden cursor-pointer hover:opacity-80 transition-opacity border-2 border-primary/50 ${isSpinning ? 'profile-spin' : ''}`} 
                  style={{boxShadow: "0 0 20px rgba(239, 68, 68, 0.6)"}}
                >
                  {user?.profilePicture ? (
                    <img src={user.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center text-white font-bold">
                      {user?.username?.charAt(0).toUpperCase() || "U"}
                    </div>
                  )}
                </div>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-8 sm:py-12">
        <div className="mb-8 sm:mb-12">
          <h2 className="text-4xl sm:text-5xl font-black mb-2 text-foreground">Shop <span className="text-primary">Products</span></h2>
          <p className="text-sm sm:text-base text-muted-foreground">Browse our premium selection</p>
        </div>

        {/* Category Filter */}
        <div className="mb-8 sm:mb-12">
          <div className="flex gap-2 sm:gap-3 overflow-x-auto pb-2">
            {CATEGORIES.map((cat) => (
              <Button
                key={cat}
                variant={selectedCategory === cat ? "default" : "outline"}
                onClick={() => setSelectedCategory(cat)}
                className="whitespace-nowrap text-xs sm:text-sm"
              >
                {cat}
              </Button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Products List */}
          <div className="lg:col-span-1">
            <h3 className="text-lg sm:text-xl font-bold mb-4 text-foreground">Available Products</h3>
            <div className="space-y-3">
              {filteredProducts.map((product) => (
                <Card
                  key={product.id}
                  className={`cursor-pointer transition-all border-2 ${
                    selectedProduct.id === product.id
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/50"
                  }`}
                  onClick={() => setSelectedProduct(product)}
                >
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-foreground mb-1">{product.name}</h4>
                    <p className="text-xs sm:text-sm text-muted-foreground mb-2">{product.category}</p>
                    {product.available ? (
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-primary">${product.price}/g</span>
                        <span className="text-xs bg-green-500/20 text-green-600 px-2 py-1 rounded">In Stock</span>
                      </div>
                    ) : (
                      <span className="text-xs bg-gray-500/20 text-gray-600 px-2 py-1 rounded">Coming Soon</span>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="lg:col-span-2">
            {selectedProduct.available ? (
              <>
                {/* Product Card */}
                <Card className="border-2 border-primary/30 mb-8">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <CardTitle className="text-2xl sm:text-3xl">{selectedProduct.name}</CardTitle>
                          {!storeStatus?.inStock && (
                            <span className="bg-red-500/20 text-red-700 text-xs font-bold px-3 py-1 rounded-full border border-red-500/50">OUT OF STOCK</span>
                          )}
                        </div>
                        <CardDescription className="text-base mt-2">{selectedProduct.category}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Product Image */}
                    {selectedProduct.image && (
                      <div className="w-full h-64 sm:h-80 bg-card border border-border rounded-lg flex items-center justify-center">
                        <img src={selectedProduct.image} alt={selectedProduct.name} className="w-full h-full object-contain p-4" />
                      </div>
                    )}

                    {/* Description */}
                    <p className="text-sm sm:text-base text-muted-foreground">{selectedProduct.description}</p>

                    {/* Rating */}
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < Math.round(parseFloat(averageRating))
                                ? "fill-primary text-primary"
                                : "text-muted-foreground"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm font-semibold text-foreground">{averageRating}</span>
                      <span className="text-xs text-muted-foreground">({reviews?.length || 0} reviews)</span>
                    </div>

                    {/* Pricing */}
                    <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground mb-2">Price per gram</p>
                      <p className="text-3xl sm:text-4xl font-black text-primary">${selectedProduct.price}</p>
                    </div>

                    {/* Store Status Messages */}
                    {!storeStatus?.isOpen && (
                      <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-lg p-4">
                        <p className="text-sm font-semibold text-yellow-700">Store Closed</p>
                        <p className="text-xs text-yellow-600 mt-1">{storeStatus?.closedMessage || "The store is currently closed"}</p>
                      </div>
                    )}

                    {!storeStatus?.inStock && (
                      <div className="bg-red-500/20 border border-red-500/50 rounded-lg p-4">
                        <p className="text-sm font-semibold text-red-700">Out of Stock</p>
                        <p className="text-xs text-red-600 mt-1">This product is temporarily unavailable</p>
                      </div>
                    )}

                    {/* Quantity Selection */}
                    <div className="space-y-4">
                      <div>
                        <Label className="text-sm font-semibold mb-3 block">Select Quantity</Label>
                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
                          {presetQuantities.map((q) => (
                            <Button
                              key={q}
                              variant={!useCustom && quantity === q ? "default" : "outline"}
                              onClick={() => {
                                setQuantity(q);
                                setUseCustom(false);
                              }}
                              className="text-xs sm:text-sm"
                            >
                              {q}g
                            </Button>
                          ))}
                        </div>
                        <Button
                          variant={useCustom ? "default" : "outline"}
                          onClick={() => setUseCustom(!useCustom)}
                          className="w-full text-xs sm:text-sm"
                        >
                          Custom Amount
                        </Button>
                      </div>

                      {useCustom && (
                        <div>
                          <Label htmlFor="custom-qty" className="text-xs sm:text-sm">Enter amount (grams, minimum 2g)</Label>
                          <Input
                            id="custom-qty"
                            type="number"
                            step="0.5"
                            min="2"
                            placeholder="e.g., 3.5"
                            value={customQuantity}
                            onChange={(e) => setCustomQuantity(e.target.value)}
                            className="mt-2 text-sm"
                          />
                        </div>
                      )}
                    </div>

                    {/* Telegram Username Display */}
                    {isAuthenticated && (
                      <div className="bg-card border border-border rounded-lg p-4">
                        <p className="text-xs text-muted-foreground mb-1">Order will be placed under</p>
                        <p className="text-sm font-semibold text-foreground">
                          {user?.telegramUsername ? `@${user.telegramUsername}` : "No Telegram username set"}
                        </p>
                        {!user?.telegramUsername && (
                          <Link href="/profile">
                            <Button variant="link" size="sm" className="text-xs mt-2 p-0">
                              Set Telegram username
                            </Button>
                          </Link>
                        )}
                      </div>
                    )}

                    {/* Order Button */}
                    <Button
                      onClick={handlePlaceOrder}
                      disabled={
                        createOrderMutation.isPending ||
                        !storeStatus?.isOpen ||
                        !storeStatus?.inStock ||
                        !isAuthenticated ||
                        !user?.telegramUsername
                      }
                      className="w-full text-base sm:text-lg py-6 sm:py-8 font-bold bg-primary hover:bg-primary/90"
                    >
                      {!isAuthenticated ? "Login to Order" : !user?.telegramUsername ? "Set Telegram Username" : "Place Order"}
                    </Button>
                  </CardContent>
                </Card>

                {/* Reviews Section */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl sm:text-2xl font-bold mb-4 text-foreground">Reviews</h3>

                    {!showReviewForm && (
                      <Button
                        onClick={() => setShowReviewForm(true)}
                        variant="outline"
                        className="w-full mb-6 text-sm sm:text-base"
                      >
                        {isEditing ? "Edit Your Review" : "Write a Review"}
                      </Button>
                    )}

                    {showReviewForm && (
                      <Card className="border-primary/30 mb-6">
                        <CardContent className="pt-6 space-y-4">
                          <div>
                            <Label className="text-sm font-semibold mb-2 block">Rating</Label>
                            <div className="flex gap-2">
                              {[1, 2, 3, 4, 5].map((r) => (
                                <button
                                  key={r}
                                  onClick={() => setRating(r)}
                                  className="focus:outline-none"
                                >
                                  <Star
                                    className={`w-8 h-8 ${
                                      r <= rating
                                        ? "fill-primary text-primary"
                                        : "text-muted-foreground"
                                    }`}
                                  />
                                </button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <Label htmlFor="review" className="text-sm font-semibold mb-2 block">Your Review</Label>
                            <Textarea
                              id="review"
                              placeholder="Share your experience..."
                              value={reviewComment}
                              onChange={(e) => setReviewComment(e.target.value)}
                              className="text-sm"
                            />
                          </div>

                          <div className="flex gap-2">
                            <Button
                              onClick={handleSubmitReview}
                              disabled={createReviewMutation.isPending || updateReviewMutation.isPending}
                              className="flex-1 text-sm"
                            >
                              {isEditing ? "Update Review" : "Post Review"}
                            </Button>
                            <Button
                              onClick={() => setShowReviewForm(false)}
                              variant="outline"
                              className="flex-1 text-sm"
                            >
                              Cancel
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    {/* Reviews List */}
                    <div className="space-y-4">
                      {reviews && reviews.length > 0 ? (
                        reviews.map((review) => (
                          <Card key={review.id} className="border-border">
                            <CardContent className="pt-6">
                              <Link href={`/user/${review.userId}`}>
                                <div className="flex items-start gap-4 cursor-pointer hover:opacity-80 transition-opacity">
                                  {review.user?.profilePicture && (
                                    <img
                                      src={review.user.profilePicture}
                                      alt="User"
                                      className="w-10 h-10 rounded-full object-cover"
                                    />
                                  )}
                                  <div className="flex-1">
                                    <p className="font-semibold text-foreground text-sm sm:text-base">{review.user?.username || review.user?.name || "Anonymous"}</p>
                                    <div className="flex items-center gap-2 mt-1">
                                      <div className="flex gap-1">
                                        {[...Array(5)].map((_, i) => (
                                          <Star
                                            key={i}
                                            className={`w-3 h-3 ${
                                              i < review.rating
                                                ? "fill-primary text-primary"
                                                : "text-muted-foreground"
                                            }`}
                                          />
                                        ))}
                                      </div>
                                      <span className="text-xs text-muted-foreground">
                                        {review.createdAt ? new Date(review.createdAt).toLocaleDateString() : ""}
                                      </span>
                                    </div>
                                    {review.comment && (
                                      <p className="text-sm text-muted-foreground mt-2">{review.comment}</p>
                                    )}
                                  </div>
                                </div>
                              </Link>
                            </CardContent>
                          </Card>
                        ))
                      ) : (
                        <p className="text-sm text-muted-foreground text-center py-8">No reviews yet. Be the first to review!</p>
                      )}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <Card className="border-2 border-primary/30 h-full flex items-center justify-center">
                <CardContent className="text-center py-16 sm:py-24">
                  <Lock className="w-16 h-16 sm:w-20 sm:h-20 text-muted-foreground mx-auto mb-4 opacity-50" />
                  <h3 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Coming Soon</h3>
                  <p className="text-sm sm:text-base text-muted-foreground max-w-sm mx-auto">
                    We're working on bringing you exciting new products. Check back soon!
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
          {/* Category Navigation */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-2 z-50">
        <Link href="/category" title="Shop">
          <button className="bg-primary/80 hover:bg-primary text-white p-3 rounded-full shadow-lg transition-all hover:scale-110">
            <ShoppingBag className="w-5 h-5" />
          </button>
        </Link>
        <Link href="/orders" title="Orders">
          <button className="bg-primary/80 hover:bg-primary text-white p-3 rounded-full shadow-lg transition-all hover:scale-110">
            <Package className="w-5 h-5" />
          </button>
        </Link>
      </div>
      </div>
  );
}

