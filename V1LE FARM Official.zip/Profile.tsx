import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { useState, useEffect, useRef } from "react";
import ImageCropDialog from "@/components/ImageCropDialog";
import { Camera, Edit, X, Trash2, XCircle, ShoppingBag, Package } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Link, useLocation } from "wouter";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";

export default function Profile() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const { data: profile, refetch } = trpc.profile.get.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [telegramUsername, setTelegramUsername] = useState("");
  const [profilePicture, setProfilePicture] = useState("");
  const [tempImage, setTempImage] = useState("");
  const [showCropDialog, setShowCropDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isSpinning, setIsSpinning] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const handleProfilePictureClick = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setTimeout(() => setIsSpinning(false), 800);
  };
  
  // Falling cannabis flowers effect
  useEffect(() => {
    const flowerImages = [
      '/cannabis/flower-1.png',
      '/cannabis/flower-2.png',
      '/cannabis/flower-3.png',
      '/cannabis/flower-4.png',
      '/cannabis/flower-5.png',
      '/cannabis/flower-6.png',
      '/cannabis/flower-7.png',
      '/cannabis/flower-8.png',
      '/cannabis/flower-9.png',
    ];
    
    const createFlower = () => {
      const flower = document.createElement('div');
      flower.className = 'falling-flower';
      const randomFlower = flowerImages[Math.floor(Math.random() * flowerImages.length)];
      const randomLeft = Math.random() * 100;
      const randomDuration = 8 + Math.random() * 4;
      const randomDelay = Math.random() * 2;
      
      flower.style.left = randomLeft + '%';
      flower.style.animationDuration = randomDuration + 's';
      flower.style.animationDelay = randomDelay + 's';
      flower.innerHTML = `<img src="${randomFlower}" alt="flower" />`;
      
      document.body.appendChild(flower);
      
      setTimeout(() => flower.remove(), (randomDuration + randomDelay) * 1000);
    };
    
    const interval = setInterval(createFlower, 1500);
    
    return () => clearInterval(interval);
  }, []);

  const { data: orders, refetch: refetchOrders } = trpc.orders.myOrders.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  const cancelOrderMutation = trpc.orders.cancel.useMutation({
    onSuccess: () => {
      toast.success("Order cancelled successfully!");
      refetchOrders();
    },
    onError: (error) => {
      toast.error(`Failed to cancel order: ${error.message}`);
    },
  });

  const deleteOrderMutation = trpc.orders.delete.useMutation({
    onSuccess: () => {
      toast.success("Order deleted successfully!");
      refetchOrders();
    },
    onError: (error) => {
      toast.error(`Failed to delete order: ${error.message}`);
    },
  });

  useEffect(() => {
    if (profile) {
      setName(profile.name || "");
      setUsername(profile.username || "");
      setBio(profile.bio || "");
      setTelegramUsername(profile.telegramUsername || "");
      setProfilePicture(profile.profilePicture || "");
    }
  }, [profile]);

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("authToken");
    localStorage.removeItem("user");
    toast.success("Logged out successfully!");
    setLocation("/");
  };

  
  const updateProfileMutation = trpc.profile.update.useMutation({
    onSuccess: () => {
      toast.success("Profile updated successfully!");
      setIsEditing(false);
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to update profile: ${error.message}`);
    },
  });

  const uploadPictureMutation = trpc.profile.uploadProfilePicture.useMutation({
    onSuccess: (data) => {
      setProfilePicture(data.url);
      toast.success("Profile picture uploaded successfully!");
      refetch();
    },
    onError: (error) => {
      toast.error(`Failed to upload profile picture: ${error.message}`);
    },
  });

  const handleSave = () => {
    updateProfileMutation.mutate({
      name: name.trim() || undefined,
      username: username.trim().replace("@", "") || undefined,
      bio: bio.trim() || undefined,
      telegramUsername: telegramUsername.trim().replace("@", "") || undefined,
    });
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type - support all images except GIF
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp', 'image/bmp', 'image/tiff', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      toast.error("Please upload a valid image file (JPEG, PNG, WebP, BMP, TIFF, SVG). GIFs and videos are not supported.");
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setTempImage(reader.result as string);
      setShowCropDialog(true);
    };
    reader.readAsDataURL(file);
  };

  const handleCropComplete = async (croppedImage: string) => {
    // Upload the cropped image immediately
    uploadPictureMutation.mutate({ base64Image: croppedImage });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardHeader>
            <CardTitle>Authentication Required</CardTitle>
            <CardDescription>Please log in to view your profile</CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild>
              <a href="/login">Login with Telegram</a>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background grainy-bg">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer">
              <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
              <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-2 sm:gap-4">
            <Link href="/category">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Shop</Button>
            </Link>
            <Link href="/orders">
              <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Orders</Button>
            </Link>
            {user?.role === "admin" && (
              <Link href="/admin">
                <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Admin</Button>
              </Link>
            )}
              <Link href="/profile">
                <div 
                  onClick={handleProfilePictureClick}
                  className={`relative w-10 h-10 sm:w-12 sm:h-12 rounded-full overflow-hidden cursor-pointer hover:opacity-80 transition-opacity border-2 border-primary/50 ${isSpinning ? 'profile-spin' : ''}`} 
                  style={{boxShadow: "0 0 20px rgba(239, 68, 68, 0.6)"}}
                >
                  {user?.profilePicture ? (
                    <img src={user.profilePicture} alt="Profile" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center text-white font-bold">
                      {user?.username?.charAt(0).toUpperCase() || "U"}
                    </div>
                  )}
                </div>
              </Link>
          </nav>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-3xl sm:text-4xl font-bold mb-6 sm:mb-8 text-foreground">My Profile</h2>

          <Card className="bg-card border-border">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Account Information</CardTitle>
                  <CardDescription>
                    {isEditing ? "Update your profile details" : "View your profile information"}
                  </CardDescription>
                </div>
                <Button
                  variant={isEditing ? "outline" : "default"}
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  {isEditing ? (
                    <>
                      <X className="w-4 h-4 mr-2" />
                      Cancel
                    </>
                  ) : (
                    <>
                      <Edit className="w-4 h-4 mr-2" />
                      Edit
                    </>
                  )}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full bg-primary/20 flex items-center justify-center overflow-hidden">
                    {profilePicture ? (
                      <img src={profilePicture} alt="Profile" className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-5xl font-bold text-primary">
                        {username?.[0]?.toUpperCase() || name?.[0]?.toUpperCase() || "?"}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute bottom-0 right-0 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center hover:bg-primary/90 transition-colors disabled:opacity-50"
                    type="button"
                    disabled={uploadPictureMutation.isPending}
                  >
                    {uploadPictureMutation.isPending ? (
                      <span className="text-xs">...</span>
                    ) : (
                      <Camera className="w-5 h-5" />
                    )}
                  </button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/jpeg,image/jpg,image/png,image/webp,image/bmp,image/tiff,image/svg+xml"
                  onChange={handleFileSelect}
                  className="hidden"
                />
                <p className="text-xs text-muted-foreground text-center">
                  {uploadPictureMutation.isPending
                    ? "Uploading..."
                    : "Click the camera icon to upload a profile picture"}
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="name">Display Name</Label>
                {isEditing ? (
                  <Input
                    id="name"
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                ) : (
                  <p className="text-sm text-foreground py-2">{name || "Not set"}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                {isEditing ? (
                  <>
                    <Input
                      id="username"
                      placeholder="@username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Your unique username shown on reviews
                    </p>
                  </>
                ) : (
                  <p className="text-sm text-foreground py-2">
                    {username ? `@${username}` : "Not set"}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                {isEditing ? (
                  <>
                    <Textarea
                      id="bio"
                      placeholder="Tell us about yourself..."
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      rows={4}
                      className="resize-none"
                    />
                    <p className="text-xs text-muted-foreground">
                      Share a bit about yourself (optional)
                    </p>
                  </>
                ) : (
                  <p className="text-sm text-foreground py-2 whitespace-pre-wrap">
                    {bio || "No bio added yet"}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="telegram">Telegram Username *</Label>
                {isEditing ? (
                  <>
                    <Input
                      id="telegram"
                      placeholder="@yourusername"
                      value={telegramUsername}
                      onChange={(e) => setTelegramUsername(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Required for order notifications and communication
                    </p>
                  </>
                ) : (
                  <p className="text-sm text-foreground py-2">
                    {telegramUsername ? `@${telegramUsername}` : "Not set"}
                  </p>
                )}
              </div>

              <div className="pt-4 border-t border-border">
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Email:</span>
                    <span className="font-medium">{profile?.email || "Not set"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Account Role:</span>
                    <span className="font-medium capitalize">{profile?.role || "user"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Member Since:</span>
                    <span className="font-medium">
                      {profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : "N/A"}
                    </span>
                  </div>
                </div>
              </div>

              {isEditing && (
                <Button 
                  className="w-full" 
                  onClick={handleSave}
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Order History Section */}
          <Card className="bg-card border-border mt-6">
            <CardHeader>
              <CardTitle>Order History</CardTitle>
              <CardDescription>Your recent orders</CardDescription>
            </CardHeader>
            <CardContent>
              {orders && orders.length > 0 ? (
                <div className="space-y-4">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="border border-border rounded-lg p-4 hover:border-primary/50 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-semibold text-foreground">{order.productName}</h4>
                          <p className="text-sm text-muted-foreground">
                            {order.quantity}g × ${order.pricePerGram}/g
                          </p>
                        </div>
                        <Badge
                          variant={
                            order.status === "approved"
                              ? "default"
                              : order.status === "rejected"
                              ? "destructive"
                              : "secondary"
                          }
                        >
                          {order.status}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between text-sm mt-3 pt-3 border-t border-border">
                        <span className="text-muted-foreground">
                          {order.createdAt ? new Date(order.createdAt).toLocaleDateString() : ""}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-primary">${order.totalPrice}</span>
                          {order.status === "pending" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => cancelOrderMutation.mutate({ orderId: order.id })}
                              disabled={cancelOrderMutation.isPending}
                            >
                              <XCircle className="w-4 h-4 mr-1" />
                              Cancel
                            </Button>
                          )}
                          {(order.status === "rejected" || order.status === "cancelled" || order.status === "completed") && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => deleteOrderMutation.mutate({ orderId: order.id })}
                              disabled={deleteOrderMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground mb-4">No orders yet</p>
                  <Link href="/shop">
                    <Button>Browse Products</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <ImageCropDialog
        open={showCropDialog}
        onClose={() => setShowCropDialog(false)}
        imageSrc={tempImage}
        onCropComplete={handleCropComplete}
      />

      <footer className="border-t border-border py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 V1LE Farm. All rights reserved.</p>
        </div>
      </footer>
          {/* Category Navigation */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-2 z-50">
        <Link href="/category" title="Shop">
          <button className="bg-primary/80 hover:bg-primary text-white p-3 rounded-full shadow-lg transition-all hover:scale-110">
            <ShoppingBag className="w-5 h-5" />
          </button>
        </Link>
        <Link href="/orders" title="Orders">
          <button className="bg-primary/80 hover:bg-primary text-white p-3 rounded-full shadow-lg transition-all hover:scale-110">
            <Package className="w-5 h-5" />
          </button>
        </Link>
      </div>
      </div>
  );
}

