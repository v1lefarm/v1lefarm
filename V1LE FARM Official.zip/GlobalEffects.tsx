import { useEffect } from 'react';

export default function GlobalEffects() {
  // Falling cannabis flowers effect
  useEffect(() => {
    const flowerImages = [
      '/cannabis/flower-1.png',
      '/cannabis/flower-2.png',
      '/cannabis/flower-3.png',
      '/cannabis/flower-4.png',
      '/cannabis/flower-5.png',
      '/cannabis/flower-6.png',
      '/cannabis/flower-7.png',
      '/cannabis/flower-8.png',
      '/cannabis/flower-9.png',
    ];
    
    const createFlower = () => {
      const flower = document.createElement('div');
      flower.className = 'falling-flower';
      const randomFlower = flowerImages[Math.floor(Math.random() * flowerImages.length)];
      const randomLeft = Math.random() * 100;
      const randomDuration = 8 + Math.random() * 4;
      const randomDelay = Math.random() * 2;
      
      flower.style.left = randomLeft + '%';
      flower.style.animationDuration = randomDuration + 's';
      flower.style.animationDelay = randomDelay + 's';
      flower.innerHTML = `<img src="${randomFlower}" alt="flower" style="width: 80px; height: 80px; opacity: 0.7;" />`;
      
      document.body.appendChild(flower);
      
      setTimeout(() => flower.remove(), (randomDuration + randomDelay) * 1000);
    };
    
    const interval = setInterval(createFlower, 1500);
    
    return () => clearInterval(interval);
  }, []);

  return null;
}

