import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { Shield, Lock, Zap, Users, Settings, ShoppingBag, Package, BarChart3 } from "lucide-react";
import { useState, useEffect } from "react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [isSpinning, setIsSpinning] = useState(false);
  
  const handleProfilePictureClick = () => {
    if (isSpinning) return;
    setIsSpinning(true);
    setTimeout(() => setIsSpinning(false), 800);
  };
  
  // Falling cannabis flowers effect
  useEffect(() => {
    const flowerImages = [
      '/cannabis/flower-1.png',
      '/cannabis/flower-2.png',
      '/cannabis/flower-3.png',
      '/cannabis/flower-4.png',
      '/cannabis/flower-5.png',
      '/cannabis/flower-6.png',
      '/cannabis/flower-7.png',
      '/cannabis/flower-8.png',
      '/cannabis/flower-9.png',
    ];
    
    const createFlower = () => {
      const flower = document.createElement('div');
      flower.className = 'falling-flower';
      const randomFlower = flowerImages[Math.floor(Math.random() * flowerImages.length)];
      const randomLeft = Math.random() * 100;
      const randomDuration = 8 + Math.random() * 4;
      const randomDelay = Math.random() * 2;
      
      flower.style.left = randomLeft + '%';
      flower.style.animationDuration = randomDuration + 's';
      flower.style.animationDelay = randomDelay + 's';
      flower.innerHTML = `<img src="${randomFlower}" alt="flower" />`;
      
      document.body.appendChild(flower);
      
      setTimeout(() => flower.remove(), (randomDuration + randomDelay) * 1000);
    };
    
    const interval = setInterval(createFlower, 1500);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background grainy-bg">
      {/* Header */}
      <header className="border-b border-primary/20 bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3">
            <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
            <h1 className="text-xl sm:text-2xl font-bold text-primary">V1LE Farm</h1>
          </div>
          <nav className="flex items-center gap-1 sm:gap-3">
            {isAuthenticated ? (
              <>
                <Link href="/category">
                  <Button variant="ghost" size="sm" className="hover:bg-primary/10 p-2" title="Shop">
                    <ShoppingBag className="w-5 h-5" />
                  </Button>
                </Link>
                <Link href="/orders">
                  <Button variant="ghost" size="sm" className="hover:bg-primary/10 p-2" title="Orders">
                    <Package className="w-5 h-5" />
                  </Button>
                </Link>
                {user?.role === "admin" && (
                  <Link href="/admin">
                    <Button variant="ghost" size="sm" className="hover:bg-primary/10 p-2" title="Admin">
                      <BarChart3 className="w-5 h-5" />