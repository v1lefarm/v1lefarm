import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";

interface Product {
  name: string;
  pricePerGram: number;
  inStock: boolean;
  description?: string;
}

const PRODUCTS: Record<string, Product> = {
  "God Complex": {
    name: "God Complex",
    pricePerGram: 10,
    inStock: true,
    description: "Premium strain with complex flavor profile",
  },
  "Blue Dream": {
    name: "Blue Dream",
    pricePerGram: 12,
    inStock: true,
    description: "Balanced hybrid with berry notes",
  },
  "OG Kush": {
    name: "OG Kush",
    pricePerGram: 15,
    inStock: true,
    description: "Classic strain with earthy undertones",
  },
};

const PRESET_QUANTITIES = [2, 2.5, 5, 10];

export default function CategoryEnhanced() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const [selectedProduct, setSelectedProduct] = useState<string>("God Complex");
  const [quantity, setQuantity] = useState<number>(2);
  const [customQuantity, setCustomQuantity] = useState<string>("");
  const [telegramUsername, setTelegramUsername] = useState(user?.telegramUsername || "");
  const [isLoading, setIsLoading] = useState(false);

  const storeStatusQuery = trpc.store.getStatus.useQuery();
  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: () => {
      toast.success("Order placed successfully!");
      setQuantity(2);
      setCustomQuantity("");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to place order");
    },
  });

  const product = PRODUCTS[selectedProduct];
  const finalQuantity = customQuantity ? parseFloat(customQuantity) : quantity;
  const totalPrice = Math.round(finalQuantity * product.pricePerGram);
  const isOutOfStock = !product.inStock || (storeStatusQuery.data?.inStock === 0);

  const handlePlaceOrder = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!user) {
      setLocation("/login");
      return;
    }

    if (!telegramUsername) {
      toast.error("Please enter your Telegram username");
      return;
    }

    if (finalQuantity <= 0) {
      toast.error("Please select a valid quantity");
      return;
    }

    if (isOutOfStock) {
      toast.error("This product is currently out of stock");
      return;
    }

    setIsLoading(true);
    createOrderMutation.mutate({
      productName: selectedProduct,
      quantity: finalQuantity,
      pricePerGram: product.pricePerGram,
      telegramUsername,
    });
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-background grainy-bg p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Shop Products</h1>

        <div className="grid md:grid-cols-2 gap-6">
          {/* Product Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Select Product</CardTitle>
              <CardDescription>Choose from our available strains</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {Object.entries(PRODUCTS).map(([name, prod]) => (
                <button
                  key={name}
                  onClick={() => setSelectedProduct(name)}
                  className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                    selectedProduct === name
                      ? "border-primary bg-primary/10"
                      : "border-border hover:border-primary/50"
                  } ${prod.inStock ? "" : "opacity-50 cursor-not-allowed"}`}
                  disabled={!prod.inStock}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{name}</h3>
                      <p className="text-sm text-muted-foreground">{prod.description}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${prod.pricePerGram}/g</p>
                      {!prod.inStock && <p className="text-xs text-destructive">OUT OF STOCK</p>}
                    </div>
                  </div>
                </button>
              ))}
            </CardContent>
          </Card>

          {/* Order Details */}
          <Card>
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
              <CardDescription>Customize your order</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePlaceOrder} className="space-y-4">
                {/* Quantity Selection */}
                <div className="space-y-2">
                  <Label>Quantity (grams)</Label>
                  <div className="grid grid-cols-4 gap-2">
                    {PRESET_QUANTITIES.map((q) => (
                      <Button
                        key={q}
                        type="button"
                        variant={quantity === q && !customQuantity ? "default" : "outline"}
                        onClick={() => {
                          setQuantity(q);
                          setCustomQuantity("");
                        }}
                        disabled={isOutOfStock}
                      >
                        {q}g
                      </Button>
                    ))}
                  </div>
                  <div className="relative">
                    <Input
                      type="number"
                      placeholder="Custom amount"
                      value={customQuantity}
                      onChange={(e) => {
                        setCustomQuantity(e.target.value);
                        if (e.target.value) setQuantity(0);
                      }}
                      step="0.1"
                      min="0.1"
                      disabled={isOutOfStock}
                    />
                  </div>
                </div>

                {/* Price Display */}
                <div className="bg-muted p-4 rounded-lg space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Quantity:</span>
                    <span className="font-semibold">{finalQuantity}g</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Price per gram:</span>
                    <span className="font-semibold">${product.pricePerGram}</span>
                  </div>
                  <div className="border-t border-border pt-2 flex justify-between">
                    <span className="font-semibold">Total Price:</span>
                    <span className="text-lg font-bold text-primary">${totalPrice}</span>
                  </div>
                </div>

                {/* Telegram Username */}
                <div className="space-y-2">
                  <Label htmlFor="telegram">Telegram Username</Label>
                  <Input
                    id="telegram"
                    type="text"
                    placeholder="@username"
                    value={telegramUsername}
                    onChange={(e) => setTelegramUsername(e.target.value)}
                    disabled={isOutOfStock || isLoading}
                  />
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  className="w-full"
                  disabled={isOutOfStock || isLoading || !telegramUsername}
                >
                  {isLoading ? "Placing Order..." : `Place Order - $${totalPrice}`}
                </Button>

                {isOutOfStock && (
                  <p className="text-sm text-destructive text-center">
                    This product is currently out of stock
                  </p>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

