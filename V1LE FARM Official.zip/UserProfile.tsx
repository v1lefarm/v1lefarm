import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link, useLocation, useRoute } from "wouter";

export default function UserProfile() {
  const [, params] = useRoute("/user/:username");
  const username = params?.username || "";
  
  const { data: user, isLoading } = trpc.profile.getByUsername.useQuery(
    { username },
    { enabled: !!username }
  );

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="border-b border-border">
          <div className="container mx-auto px-4 py-3 sm:py-4">
            <Link href="/">
              <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
              </div>
            </Link>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading profile...</p>
          </div>
        </main>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col bg-background">
        <header className="border-b border-border">
          <div className="container mx-auto px-4 py-3 sm:py-4">
            <Link href="/">
              <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
                <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
                <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
              </div>
            </Link>
          </div>
        </header>
        <main className="flex-1 container mx-auto px-4 py-6 sm:py-12">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="py-12 text-center">
              <h2 className="text-2xl font-bold mb-2">User Not Found</h2>
              <p className="text-muted-foreground mb-6">
                The user @{username} does not exist.
              </p>
              <Link href="/category">
                <Button>Back to Shop</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <header className="border-b border-border">
        <div className="container mx-auto px-4 py-3 sm:py-4 flex items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 sm:gap-3 cursor-pointer">
              <img src="/logo.v1le.png" alt="V1LE Farm" className="h-10 sm:h-12 w-auto invert" />
              <h1 className="text-xl sm:text-2xl font-bold text-foreground">V1LE Farm</h1>
            </div>
          </Link>
          <Link href="/category">
            <Button variant="ghost" size="sm" className="text-xs sm:text-sm">Back to Shop</Button>
          </Link>
        </div>