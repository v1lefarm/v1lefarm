import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { generateRainbowColors } from "@/lib/rainbowLED";
import { Link, useLocation } from "wouter";
import { Settings, ShoppingBag, Package } from "lucide-react";

export default function ProfileSettings() {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [username, setUsername] = useState(user?.username || "");
  const [telegramUsername, setTelegramUsername] = useState(user?.telegramUsername || "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [selectedColor, setSelectedColor] = useState(user?.themeColor || "#EF4444");
  const [isLoading, setIsLoading] = useState(false);

  const updateProfileMutation = trpc.profile.update.useMutation({
    onSuccess: () => {
      toast.success("Profile updated successfully!");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to update profile");
    },
  });

  const updatePasswordMutation = trpc.auth.updatePassword.useMutation({
    onSuccess: () => {
      toast.success("Password updated successfully!");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to update password");
    },
  });

  const updateEmailMutation = trpc.auth.updateEmail.useMutation({
    onSuccess: () => {
      toast.success("Email updated successfully!");
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to update email");
    },
  });

  const updateThemeColorMutation = trpc.auth.updateThemeColor.useMutation({
    onSuccess: () => {
      toast.success("Theme color updated!");
      localStorage.setItem("themeColor", selectedColor);
    },
    onError: (error: any) => {
      toast.error(error.message || "Failed to update theme color");
    },
  });

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    updateProfileMutation.mutate({ name, telegramUsername, username });
    setIsLoading(false);
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error("Please fill in all password fields");
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error("Passwords do not match");
      return;
    }

    if (newPassword.length < 6) {
      toast.error("Password must be at least 6 characters");
      return;
    }

    setIsLoading(true);
    try {
      updatePasswordMutation.mutate({ currentPassword, newPassword });
    } catch (error) {
      toast.error("Password update not fully implemented yet");
    }
    setIsLoading(false);
  };

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) {
      toast.error("Please enter an email");
      return;
    }

    setIsLoading(true);
    try {
      updateEmailMutation.mutate({ newEmail: email });
    } catch (error) {
      toast.error("Email update not fully implemented yet");
    }
    setIsLoading(false);
  };

  const handleColorChange = (color: string) => {
    setSelectedColor(color);
    updateThemeColorMutation.mutate({ themeColor: color });
  };

  const rainbowColors = generateRainbowColors("#FF0000", 12);

  return (
    <div className="min-h-screen bg-background grainy-bg p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Account Settings</h1>

        {/* Profile Information */}
        <Card>
          <CardHeader>
            <CardTitle>Profile Information</CardTitle>
            <CardDescription>Update your basic profile details</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  value={username}
                  disabled
                  className="bg-muted"
                />
                <p className="text-xs text-muted-foreground">Username cannot be changed</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="telegram">Telegram Username</Label>
                <Input
                  id="telegram"
                  type="text"
                  placeholder="@username"
                  value={telegramUsername}
                  onChange={(e) => setTelegramUsername(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Updating..." : "Update Profile"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Email Management */}
        <Card>
          <CardHeader>
            <CardTitle>Email Address</CardTitle>
            <CardDescription>Update your email address</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdateEmail} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Updating..." : "Update Email"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Password Management */}
        <Card>
          <CardHeader>
            <CardTitle>Change Password</CardTitle>
            <CardDescription>Update your account password</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="currentPassword">Current Password</Label>
                <Input
                  id="currentPassword"
                  type="password"
                  placeholder="••••••••"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="newPassword">New Password</Label>
                <Input
                  id="newPassword"
                  type="password"
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  disabled={isLoading}
                />
              </div>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? "Updating..." : "Change Password"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Theme Color Selection */}
        <Card>
          <CardHeader>
            <CardTitle>Theme Color</CardTitle>
            <CardDescription>Choose your rainbow LED theme color</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-6 gap-2">
                {rainbowColors.map((color) => (
                  <button
                    key={color}
                    onClick={() => handleColorChange(color)}
                    className={`w-full h-12 rounded-lg transition-all ${
                      selectedColor === color ? "ring-2 ring-offset-2 ring-foreground" : ""
                    }`}
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>
              <div className="flex items-center gap-2">
                <div
                  className="w-12 h-12 rounded-lg border-2"
                  style={{ backgroundColor: selectedColor }}
                />
                <div>
                  <p className="font-mono text-sm">{selectedColor}</p>
                  <p className="text-xs text-muted-foreground">Current theme color</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
          {/* Category Navigation */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-2 z-50">
        <Link href="/category" title="Shop">
          <button className="bg-primary/80 hover:bg-primary text-white p-3 rounded-full shadow-lg transition-all hover:scale-110">
            <ShoppingBag className="w-5 h-5" />
          </button>
        </Link>
        <Link href="/orders" title="Orders">
          <button className="bg-primary/80 hover:bg-primary text-white p-3 rounded-full shadow-lg transition-all hover:scale-110">
            <Package className="w-5 h-5" />
          </button>
        </Link>
      </div>
      </div>
  );
}

